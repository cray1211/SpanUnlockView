#import "SpanUnlockView.h"


#import "Masonry.h"


@interface SpanUnlockView()<UIGestureRecognizerDelegate>
{
    CGFloat spanViewMaxX;
    CGFloat spanViewMaxY;
    CGFloat lockViewMaxX;
    CGFloat lockViewMaxY;
    CGFloat itemW;
    CGFloat itemH ;
    CGFloat space;
    CGFloat unlockSpace;
    CGPoint startPoint;
    BOOL isStartAni;
}
@property (nonatomic ,strong) UIView *spanTopView;
@property (nonatomic ,strong) UILabel *titlelb;
@property (nonatomic ,strong) UILabel *subTitleLb;
@property (nonatomic ,strong) UIImageView *topImgV;
@property (nonatomic ,strong) UIView *spanContentBgView;
@property (nonatomic ,strong) UIView *spanView;
@property (nonatomic ,strong) UIView *lockView;
@property (nonatomic ,strong) UIImageView *lockImgView;
@property (nonatomic ,strong) UIImageView *unLockImgView;
@property (nonatomic ,assign) CGPoint spanViewRandomPoint;
@property (nonatomic ,assign) CGPoint lockRandomPoint;
@property (nonatomic ,strong) UIView *meddleLineView;
@property (nonatomic ,strong) UILabel *loackLb;
@end
@implementation SpanUnlockView
- (instancetype)init
{
    self = [super init];
    if (self) {
        [self addChildrenViews];
    }
    return self;
}
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addChildrenViews];
    }
    return self;
}
- (void) addChildrenViews{
    [self addSubview:self.spanTopView];
    [self addSubview:self.spanContentBgView];
    [self.spanContentBgView addSubview:self.meddleLineView];
    [self.spanContentBgView addSubview:self.lockView];
    [self.spanContentBgView addSubview:self.spanView];
    [self.spanView addSubview:self.unLockImgView];
    [self.lockView addSubview:self.lockImgView];
    [self.lockView addSubview:self.loackLb];
    self.lockImgView.hidden = NO;
    self.subTitleLb.hidden = YES;
    self.titlelb.hidden = YES;
    [self.spanTopView addSubview:self.titlelb];
    [self.spanTopView addSubview:self.subTitleLb];
    [self.spanTopView addSubview:self.topImgV];
    itemW = ScaleW(57);
    itemH = ScaleW(57);
    space = ScaleW(5);
    self.spanTopView.frame = CGRectMake(0, 0, self.bounds.size.width, ScaleW(170));
    self.spanContentBgView.frame = CGRectMake(0, CGRectGetMaxY(self.spanTopView.frame), self.bounds.size.width, self.bounds.size.height - CGRectGetMaxY(self.spanTopView.frame) - ScaleW(0));
    unlockSpace = ScaleW(10);
    [self layoutIfNeeded];
    self.spanView.frame = CGRectMake(0, 0, itemW, itemH);
    self.lockView.frame = CGRectMake(0, 0, itemW + space, itemH + space);
    self.meddleLineView.frame = CGRectMake(0, self.spanContentBgView.frame.size.height * 0.5, self.spanContentBgView.frame.size.width, 1);
    self.spanView.layer.shadowColor = UIColor.blackColor.CGColor;
    self.spanView.layer.shadowRadius = 3;
    self.spanView.layer.shadowOffset = CGSizeMake(0, 0);
    self.spanView.layer.shadowOpacity = 0.5;
    self.spanView.layer.cornerRadius = self.spanView.frame.size.width * 0.5;
    self.lockView.layer.cornerRadius = self.lockView.frame.size.width * 0.5;
    self.spanView.layer.masksToBounds = self.lockView.layer.masksToBounds = NO;
    self.topImgV.image = [[UIImage imageNamed:@"saftyTopImg"] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    self.topImgV.tintColor = UIColor.lightGrayColor;
    self.lockImgView.image = [UIImage imageNamed:@"saftylockImg"];
    self.unLockImgView.image = [UIImage imageNamed:@"saftyUnlockImg"];
    spanViewMaxX = (self.spanContentBgView.frame.size.width - self.spanView.frame.size.width);
    spanViewMaxY = (self.spanContentBgView.frame.size.height * 0.5 - self.spanView.frame.size.height);
    lockViewMaxX = (self.spanContentBgView.frame.size.width - self.lockView.frame.size.width);
    lockViewMaxY = (self.spanContentBgView.frame.size.height * 0.5 - self.lockView.frame.size.height);
    [self setUpViewPosition];
    startPoint = self.spanViewRandomPoint;
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panView:)];
    self.spanView.userInteractionEnabled = YES;
    pan.delegate = self;
    [self.spanView addGestureRecognizer:pan];
    self.loackLb.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap=  [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapLockView)];
    [self.lockView addGestureRecognizer:tap];
    self.lockView.userInteractionEnabled = YES;
    [self startScaleAnimation];
    [self.loackLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.lockView).insets(UIEdgeInsetsMake(5, 5, 5, 5));
    }];
    [self.titlelb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.spanTopView).offset(ScaleW(10));
        make.centerX.mas_equalTo(self.spanTopView);
    }];
    [self.subTitleLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.spanTopView).offset(ScaleW(-10));
        make.centerX.mas_equalTo(self.spanTopView);
    }];
    [self.topImgV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.titlelb.mas_bottom).offset(ScaleW(10));
        make.bottom.mas_equalTo(self.subTitleLb.mas_top).offset(ScaleW(-10));
        make.centerX.mas_equalTo(self.spanTopView);
        make.width.mas_equalTo(ScaleW(44));
    }];
    [self.lockImgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.lockView).insets(UIEdgeInsetsZero);
    }];
    [self.unLockImgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.spanView).insets(UIEdgeInsetsZero);
    }];
}
- (void) setUpViewPosition{
    self.spanViewRandomPoint = CGPointMake(arc4random() % (NSInteger)spanViewMaxX + self.spanView.frame.size.width * 0.5 , arc4random() % (NSInteger)spanViewMaxY + self.spanView.frame.size.height * 0.5);
    self.lockRandomPoint = CGPointMake(arc4random() % (NSInteger)lockViewMaxX + self.lockView.frame.size.width * 0.5, arc4random() % (NSInteger)lockViewMaxY + self.spanContentBgView.frame.size.height * 0.5 + self.lockView.frame.size.height * 0.5);
    self.spanView.center = self.spanViewRandomPoint;
    self.lockView.center = self.lockRandomPoint;
    [self startScaleAnimation];
}
- (void) startScaleAnimation{
    if (isStartAni) {
        return;
    }
    CABasicAnimation *scaleAnimation = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    scaleAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    scaleAnimation.duration = 0.5f;
    scaleAnimation.repeatCount = MAXFLOAT;
    scaleAnimation.autoreverses = YES;
    scaleAnimation.fromValue = [NSNumber numberWithFloat:0.9];
    scaleAnimation.toValue = [NSNumber numberWithFloat:1.1];
    [self.lockView.layer addAnimation:scaleAnimation forKey:nil];
    isStartAni = YES;
}
- (void) stopScaleAnimation{
    [self.lockView.layer removeAllAnimations];
    isStartAni = NO;
    self.lockView.transform = CGAffineTransformMakeScale(1, 1);
}
- (void) drowBorderLine:(UIView *)superView color:(UIColor *)lineColor{
    CAShapeLayer *shapLayer = [CAShapeLayer layer];
    UIBezierPath *path2 = [UIBezierPath bezierPathWithRoundedRect:superView.bounds cornerRadius:superView.bounds.size.width * 0.5];
    CGFloat dashLineConfig2[] = {4.0, 2.0, 8.0, 2.0,16.0,2.0};
    [path2 setLineDash:dashLineConfig2 count:8 phase:5];
    NSArray *dotteShapeArr2 = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:4],[NSNumber numberWithInt:2], nil];
    [shapLayer setLineDashPattern:dotteShapeArr2];
    path2.lineWidth = 2;
    [path2 stroke];
    shapLayer.fillColor = [UIColor clearColor].CGColor;
    shapLayer.strokeColor = lineColor.CGColor;
    shapLayer.path = path2.CGPath;
    [superView.layer addSublayer:shapLayer];
}
- (void) panView:(UIPanGestureRecognizer *)pan{
    CGPoint p = [pan locationInView:self.spanContentBgView];
    CGFloat currentX = 0.0;
    CGFloat currentY = 0.0;
    if (p.x >=  self.spanView.frame.size.width * 0.5 && p.x <= self.spanView.frame.size.width * 0.5 + spanViewMaxX) {
        currentX = p.x;
    }else{
        if (p.x < self.spanView.frame.size.width * 0.5  ) {
            currentX = self.spanView.frame.size.width * 0.5;
        }
        if (p.x > self.spanView.frame.size.width * 0.5 + spanViewMaxX) {
            currentX = self.spanView.frame.size.width * 0.5 + spanViewMaxX;
        }
    }
    if (p.y >= self.spanView.frame.size.height * 0.5 && p.y <=  self.spanContentBgView.frame.size.height - self.spanView.frame.size.height * 0.5) {
        currentY = p.y;
    }else{
        if (p.y < self.spanView.frame.size.height * 0.5) {
            currentY = self.spanView.frame.size.height * 0.5;
        }
        if (p.y > self.spanContentBgView.frame.size.height - self.spanView.frame.size.height * 0.5) {
            currentY = self.spanContentBgView.frame.size.height - self.spanView.frame.size.height * 0.5;
        }
    }
    self.spanView.center = CGPointMake(currentX, currentY);
    if (pan.state == UIGestureRecognizerStateBegan) {
        NSLog(@"开始拖拽");
    }else if (pan.state == UIGestureRecognizerStateChanged){
        if (fabs(self.lockView.center.y - self.spanView.center.y) <= unlockSpace && fabs(self.lockView.center.x - self.spanView.center.x) < unlockSpace) {
            [UIView animateWithDuration:0.1 animations:^{
                self.lockView.transform = CGAffineTransformMakeScale(1.2, 1.2);
            } completion:^(BOOL finished) {
                NSLog(@"您已经过");
            }];
            self.topImgV.tintColor = UIColor.greenColor;
            [self stopScaleAnimation];
        }else{
            [UIView animateWithDuration:0.1 animations:^{
                self.lockView.transform = CGAffineTransformMakeScale(1.0, 1.0);
            } completion:^(BOOL finished) {
            }];
            self.topImgV.tintColor = UIColor.lightGrayColor;
            [self startScaleAnimation];
        }
    }else if(pan.state == UIGestureRecognizerStateEnded){
        if (fabs(self.lockView.center.y - self.spanView.center.y) <= unlockSpace && fabs(self.lockView.center.x - self.spanView.center.x) < unlockSpace) {
            [UIView animateWithDuration:0.2 animations:^{
                self.spanView.transform = CGAffineTransformMakeScale(0.1, 0.1);
            } completion:^(BOOL finished) {
                self.spanView.hidden = YES;
                self.spanView.transform = CGAffineTransformMakeScale(1, 1);
                NSLog(@"您已经解锁");
                !self.unlockSuccessCallback ? : self.unlockSuccessCallback(YES);
                self.loackLb.userInteractionEnabled = YES;
                self.topImgV.tintColor = UIColor.greenColor;
                [self stopScaleAnimation];
            }];
        }else{
            [UIView animateWithDuration:0.2 animations:^{
                self.spanView.center = startPoint;
            } completion:^(BOOL finished) {
                !self.unlockSuccessCallback ? : self.unlockSuccessCallback(NO);
            }];
            [self startScaleAnimation];
            self.topImgV.tintColor = UIColor.lightGrayColor;
        }
    }
}
- (void) tapLockView{
    [self setUpViewPosition];
    self.spanView.hidden = NO;
    self.loackLb.text = @"";
    self.loackLb.userInteractionEnabled = NO;
}
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer
{
    UIView *view = gestureRecognizer.view;
    if ([gestureRecognizer isKindOfClass:[UIPanGestureRecognizer class]]) {
        CGPoint offset = [(UIPanGestureRecognizer *)gestureRecognizer translationInView:view];
        return YES;
    }
    return YES;
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveEvent:(UIEvent *)event{
    CGPoint p = [gestureRecognizer locationInView:self.spanContentBgView];
    NSLog(@"%lf      %lf", p.x, p.y);
    return YES;
}
- (void)layoutSubviews{
    [super layoutSubviews];
}
- (UIView *)spanTopView{
    if (!_spanTopView) {
        _spanTopView = [[UIView alloc] init];
        _spanTopView.backgroundColor = UIColor.whiteColor;
    }
    return _spanTopView;
}
- (UIView *)spanContentBgView{
    if (!_spanContentBgView) {
        _spanContentBgView = [[UIView alloc] init];
        _spanContentBgView.backgroundColor = UIColor.whiteColor;
    }
    return _spanContentBgView;
}
- (UIView *)spanView{
    if (!_spanView) {
        _spanView = [[UIView alloc] init];
    }
    return _spanView;
}
- (UIView *)lockView{
    if (!_lockView) {
        _lockView = [[UIView alloc] init];
        _lockView.backgroundColor = UIColor.whiteColor;
    }
    return _lockView;
}
- (UIView *)meddleLineView{
    if (!_meddleLineView) {
        _meddleLineView = [[UIView alloc] init];
        _meddleLineView.backgroundColor = UIColor.clearColor;
    }
    return _meddleLineView;
}
- (UILabel *)loackLb{
    if (!_loackLb) {
        _loackLb = [[UILabel alloc] init];
        _loackLb.font = [UIFont systemFontOfSize:20];
        _loackLb.text = @"";
        _loackLb.textColor = UIColor.greenColor;
        _loackLb.numberOfLines = 2;
        _loackLb.adjustsFontSizeToFitWidth = YES;
    }
    return _loackLb;
}
- (UILabel *)titlelb{
    if (!_titlelb) {
        _titlelb = [[UILabel alloc] init];
        _titlelb.text = @"安全验证";
        _titlelb.font = [UIFont systemFontOfSize:24];
        _titlelb.textColor = UIColor.blackColor;
    }
    return _titlelb;
}
- (UILabel *)subTitleLb{
    if (!_subTitleLb) {
        _subTitleLb = [[UILabel alloc] init];
        _subTitleLb.text = @"登录需要经过解锁认证";
        _subTitleLb.font = [UIFont systemFontOfSize:14];
        _subTitleLb.textColor = UIColor.blackColor;
    }
    return _subTitleLb;
}
- (UIImageView *)topImgV{
    if (!_topImgV) {
        _topImgV = [[UIImageView alloc] init];
        _topImgV.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _topImgV;
}
- (UIImageView *)lockImgView{
    if (!_lockImgView) {
        _lockImgView = [[UIImageView alloc] init];
        _lockImgView.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _lockImgView;
}
- (UIImageView *)unLockImgView{
    if (!_unLockImgView) {
        _unLockImgView = [[UIImageView alloc] init];
        _unLockImgView.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _unLockImgView;
}
@end
