#import <UIKit/UIKit.h>




#define ScreenWidth     ([[UIScreen mainScreen] bounds].size.width)
#define ScreenHeight    ([[UIScreen mainScreen] bounds].size.height)
#define ScaleW(width)  width*ScreenWidth/375
NS_ASSUME_NONNULL_BEGIN
@interface SpanUnlockView : UIView
@property (nonatomic ,strong) void(^unlockSuccessCallback)(BOOL succress);
@end
NS_ASSUME_NONNULL_END
