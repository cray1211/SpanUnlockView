//
//  loginViewController.h
//  滑动解锁
//
//  Created by mac on 2021/1/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface loginViewController : UIViewController
@property (nonatomic ,strong) void(^successCallback)(void);
@end

NS_ASSUME_NONNULL_END
