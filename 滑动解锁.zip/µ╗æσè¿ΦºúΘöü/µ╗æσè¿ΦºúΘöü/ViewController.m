//
//  ViewController.m
//  滑动解锁
//
//  Created by mac on 2021/1/20.
//

#import "ViewController.h"
#import "loginViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    
    
    
    
    
}

- (IBAction)loginBtnClick:(UIButton *)sender {
    
    loginViewController *vc = [[NSClassFromString(@"loginViewController") alloc] init];
    vc.successCallback = ^{
        self.title = @"登录成功";
    };
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    self.title = @"登录";
}



@end
