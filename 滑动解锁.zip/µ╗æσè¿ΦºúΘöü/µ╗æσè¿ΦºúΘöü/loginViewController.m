//
//  loginViewController.m
//  滑动解锁
//
//  Created by mac on 2021/1/20.
//

#import "loginViewController.h"
#import "SpanUnlockView.h"
@interface loginViewController ()

@end

@implementation loginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"登录";
    
    self.view.backgroundColor = UIColor.whiteColor;
    
    
    SpanUnlockView *lockViwe = [[SpanUnlockView alloc] initWithFrame:CGRectMake(15, 88, ScreenWidth - 30, ScreenHeight - 88 - 50)];
    __weak typeof(self)weakSelf = self;
    lockViwe.unlockSuccessCallback = ^(BOOL succress){
        if (succress) {
            !weakSelf.successCallback ? : weakSelf.successCallback();
            [weakSelf.navigationController popViewControllerAnimated:YES];
        }else{
            
        }
    };
    [self.view addSubview:lockViwe];
}




@end
